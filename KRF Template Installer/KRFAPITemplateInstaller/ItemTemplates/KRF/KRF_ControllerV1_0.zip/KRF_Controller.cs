﻿namespace $rootnamespace$
{
    using System.Net;
    using System.Threading.Tasks;
    using Microsoft.AspNetCore.Authorization;
    using Microsoft.AspNetCore.Mvc;

    using KRFCommon.Context;
    using KRFCommon.Controller;
    using KRFCommon.CQRS.Command;
    using KRFCommon.CQRS.Query;

    [ApiController]
    [Route("root/")]
    public class $safeitemname$ : KRFController
    {
        [HttpGet("get")]
        [ProducesResponseType((int)HttpStatusCode.OK, Type = typeof(QueryResponse))]
        public async Task<IActionResult> ListAll(
                [FromServices] IQuery<QueryRequest, QueryResponse> query,
                [FromQuery] string value)
        {
            return await this.ExecuteAsyncQuery(new QueryRequest { Value = value }, query);
        }

        [Authorize]
        [HttpGet("authorized_get")]
        [ProducesResponseType((int)HttpStatusCode.OK, Type = typeof(QueryResponse))]
        public async Task<IActionResult> ListAll(
                [FromServices] IQuery<QueryRequest, QueryResponse> query,
                [FromQuery] string value)
        {
            return await this.ExecuteAsyncQuery(new QueryRequest { Value = value }, query);
        }

        [Authorize(Policies.Admin)]
        [HttpGet("admin_get")]
        [ProducesResponseType((int)HttpStatusCode.OK, Type = typeof(QueryResponse))]
        public async Task<IActionResult> ListAll(
                [FromServices] IQuery<QueryRequest, QueryResponse> query,
                [FromQuery] string value)
        {
            return await this.ExecuteAsyncQuery(new QueryRequest { Value = value }, query);
        }

        [Authorize]
        [HttpPost("post")]
        [ProducesResponseType((int)HttpStatusCode.OK, Type =typeof(CommadResponse))]
        public async Task<IActionResult> PostSampleData(
            [FromBody] CommadRequest request,
            [FromServices] ICommand<CommadRequest, CommadResponse> command)
        {
            return await this.ExecuteAsyncCommand(request, command);
        }
    }
}
