﻿namespace $rootnamespace$
{
    using Microsoft.EntityFrameworkCore;

    public class $safeitemname$ : DbContext
    {
        public $safeitemname$(DbContextOptions options) : base(options)
        {
        }

        //context tables
        public DbSet<TableModel> TableModels { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            //Configure table and seed initial data
            modelBuilder.Entity<TableModel>(e => {
                TableModelConfiguration.Configure(e);
                TableModelSeeder.Seed(e);
            });
        }
    }
}