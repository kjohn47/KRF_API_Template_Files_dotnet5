﻿namespace $rootnamespace$
{
    using System;
    using System.Threading.Tasks;
    using System.Linq;
    using System.Collections.Generic;
    using Microsoft.EntityFrameworkCore;
    using KRFCommon.Database;

    public class $safeitemname$ : IDisposable
    {
        private readonly KrfDBContext _krfDBContext;
        public $safeitemname$(KrfDBContext krfDBContext)
        {
            this._krfDBContext = krfDBContext;
        }

        //Get data from database
        public async Task<IEnumerable<TableModel>> GetDataAsync()
        {
            //Use entity framework
            return await this._krfDBContext.TableModel.AsNoTracking().ToListAsync();
        }

        //publish data to database (using status output)
        public async Task<IQueryCommand> PublishDataAsync(string value)
        {
            //Use entity framework
            /*
            Can be returned error with condition

            if (error condition)
            {
                return new QueryCommand
                {
                    Result = QueryResultEnum.Error,
                    ResultDescription = "Error description"
                };
            }
            */

            //Create new data object
            var newData = new TableModel
            {
                Value = value
            };

            //add to database
            await this._krfDBContext.TableModel.AddAsync(newData);

            //save all changes
            await this._krfDBContext.SaveChangesAsync();

            //return success status
            return new QueryCommand {
                Result = QueryResultEnum.Success,
                ResultDescription = "Success Message"
            };
        }

        public void Dispose()
        {
            this._krfDBContext.Dispose();
        }
    }
}