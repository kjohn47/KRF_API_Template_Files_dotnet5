﻿namespace $rootnamespace$
{
    using System;
    using System.Threading.Tasks;    
    using KRFCommon.CQRS.Query;
    using KRFCommon.CQRS.Common;

    public class $safeitemname$ : IQuery<QueryRequest, QueryResponse>
    {
        public $safeitemname$(/*Import dependencies from injection*/)
        {
            //Assign dependencies to local private variables
        }

        public async Task<IResponseOut<QueryResponse>> QueryAsync(QueryRequest request)
        {   
            /*
            Add Logic for query on this part


            Use this code to generate error output
           
            if(error condition)
            {
                return ResponseOut<QueryResponse>.GenerateFault(new ErrorOut(System.Net.HttpStatusCode.BadRequest, "Error Ocurred Message", ResponseErrorType.Error));
            }
            */

            return ResponseOut<QueryResponse>.GenerateResult(new QueryResponse
            {
                Value = null
            });
        }
    }
}
