﻿namespace $ext_projectname$.Domain.Database.Sample
{
    public class SampleTable
    {
        public string Code { get; set; }
        public string Description { get; set; }
        public int TemperatureMin { get; set; }
        public int TemperatureMax { get; set; }
    }
}
