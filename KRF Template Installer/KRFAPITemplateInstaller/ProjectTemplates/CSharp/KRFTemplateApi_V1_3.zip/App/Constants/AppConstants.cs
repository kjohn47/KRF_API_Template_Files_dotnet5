﻿namespace $ext_projectname$.App.Constants
{
    public static class AppConstants
    {
        public const string SampleCacheKey = "SAMPLE_CACHE";
    }
}
