﻿namespace $rootnamespace$
{
    using System;
    using System.Threading.Tasks;

    using KRFCommon.CQRS.Command;
    using KRFCommon.CQRS.Common;
    using KRFCommon.CQRS.Validator;

    public class $safeitemname$ : ICommand<CommandRequest, CommandResponse>
    {
        public $safeitemname$(/*Import dependencies from injection*/)
        {
            //Assign dependencies to local private variables
        }

        public async Task<ICommandValidationError> ExecuteValidationAsync(CommandRequest request)
        {
            //define the Command Validator handler or add it as dependency injection
            IKRFValidator<CommandRequest> validator = new CommandValidator();
            return await validator.CheckValidationAsync(request);
        }

        public async Task<IResponseOut<CommandResponse>> ExecuteCommandAsync(CommandRequest request)
        {
            /*
            Add Logic for query on this part


            Use this code to generate error output

            if(error condition)
            {
                return ResponseOut<CommandResponse>.GenerateFault( new ErrorOut( System.Net.HttpStatusCode.BadRequest, "error message", ResponseErrorType.Error ) );
            }

            */
            return ResponseOut<CommandResponse>.GenerateResult( new CommandResponse { Value = null } );
        }
    }
}
