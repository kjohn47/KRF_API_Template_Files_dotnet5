﻿namespace $rootnamespace$
{
    using KRFCommon.CQRS.Command;

    public class $safeitemname$: ICommandRequest
    {
        public string Value { get; set; }
    }
}
