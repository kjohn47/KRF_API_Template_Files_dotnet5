﻿namespace $rootnamespace$
{
    using System.Net;
    using FluentValidation;
    using KRFCommon.CQRS.Validator;
    

    public class $safeitemname$: KRFValidator<CommandRequest>, IKRFValidator<CommandRequest>
    {
        public $safeitemname$(): base()
        {
            //Use Fluent Validation to validate your request input 
            
            this.RuleFor(r => r.Value)
                .NotNull()
                .WithErrorCode(HttpStatusCode.BadRequest.ToString())
                .WithMessage("You must add a value error")
                .NotEmpty()
                .WithErrorCode(HttpStatusCode.OK.ToString())
                .WithMessage("Value cannot be empty error");
        }
    }
}
