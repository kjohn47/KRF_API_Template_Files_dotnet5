﻿namespace $rootnamespace$
{
    using KRFCommon.CQRS.Query;

    public class $safeitemname$: IQueryRequest
    {
        public string Value { get; set; }
    }
}
