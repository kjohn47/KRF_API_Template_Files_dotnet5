﻿namespace $rootnamespace$
{  
    using KRFCommon.CQRS.Query;

    public class $safeitemname$ : IQueryResponse
    {
        public string Value { get; set; }
    }
}
