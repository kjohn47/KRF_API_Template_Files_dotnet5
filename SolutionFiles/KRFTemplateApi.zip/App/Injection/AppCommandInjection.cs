﻿namespace $ext_projectname$.App.Injection
{

    using Microsoft.Extensions.DependencyInjection;
    
    using KRFCommon.CQRS.Command;
    
    using $ext_projectname$.App.CQRS.Sample.Command;
    using $ext_projectname$.Domain.CQRS.Sample.Command;

    public static class AppCommandInjection
    {
        public static void InjectCommand(IServiceCollection services)
        {
            services.AddTransient<ICommand<SampleCommandInput, SampleCommandOutput>, PostSampleData>();
        }
    }
}
