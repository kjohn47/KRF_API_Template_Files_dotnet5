﻿namespace $ext_projectname$.App.Injection
{
    using Microsoft.Extensions.DependencyInjection;

    public static class AppProxyInjection
    {
        public static void InjectProxy(IServiceCollection services)
        {

        }
    }
}
