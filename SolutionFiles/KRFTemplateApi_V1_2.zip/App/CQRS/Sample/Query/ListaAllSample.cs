﻿namespace $ext_projectname$.App.CQRS.Sample.Query
{
    using System;
    using System.Threading.Tasks;
    using System.Collections.Generic;
    using System.Linq;

    using Microsoft.Extensions.Caching.Memory;
    
    using KRFCommon.CQRS.Query;
    using KRFCommon.CQRS.Common;

    using $ext_projectname$.Domain.CQRS.Sample.Query;
    using $ext_projectname$.Domain.Database.Sample;
    using $ext_projectname$.App.DatabaseQueries;
    using $ext_projectname$.App.Model;
    using $ext_projectname$.App.Constants;

    public class ListaAllSample : IQuery<ListSampleInput, ListSampleOutput>
    {
        private ISampleDatabaseQuery _sampleDB;
        private readonly MemoryCacheSettings _memoryCacheSettings;
        private readonly IMemoryCache _memoryCache;

        public ListaAllSample( Lazy<ISampleDatabaseQuery> sampleDB, MemoryCacheSettings memoryCacheSettings, IMemoryCache memoryCache )
        {
            this._sampleDB = sampleDB.Value;
            this._memoryCacheSettings = memoryCacheSettings;
            this._memoryCache = memoryCache;
        }

        public async Task<IResponseOut<ListSampleOutput>> QueryAsync(ListSampleInput request)
        {
            IEnumerable<SampleTable> result = null;

            if ( this._memoryCache.TryGetValue( AppConstants.SampleCacheKey, out IEnumerable<SampleTable> cachedResult ) )
            {
                if( !string.IsNullOrEmpty( request?.Code ) )
                {
                    result = cachedResult.Where( x => x.Code.Contains( request.Code, StringComparison.InvariantCultureIgnoreCase ) );
                }
                else
                {
                    result = cachedResult;
                }
            }
            else
            {
                result = await this._sampleDB.GetSampleListAsync(request?.Code);
                if( string.IsNullOrEmpty( request?.Code ) )
                {
                    this._memoryCache.Set(
                        AppConstants.SampleCacheKey,
                        result,
                        new DateTimeOffset( DateTime.Now.AddMinutes( this._memoryCacheSettings.SampleCacheDuration ) ) );
                }
            }
            
            if(result == null || !result.Any())
            {
                return ResponseOut<ListSampleOutput>.GenerateFault(new ErrorOut(System.Net.HttpStatusCode.BadRequest, "Error Ocurred: no results", ResponseErrorType.Database));
            }

            return ResponseOut<ListSampleOutput>.GenerateResult(new ListSampleOutput
            {
                Samples = result
            });
        }
    }
}