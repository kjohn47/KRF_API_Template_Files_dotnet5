﻿namespace $ext_projectname$.App.Model
{
    using KRFCommon.MemoryCache;
    public class MemoryCacheSettings : MemoryCacheSettingsBase
    {
        private const int DefaultSampleDuration = 120;

        private int? _sampleCacheDuration;

        public int SampleCacheDuration
        {
            get
            {
                if ( this._sampleCacheDuration.HasValue )
                {
                    return this._sampleCacheDuration.Value;
                }

                this._sampleCacheDuration = DefaultSampleDuration;
                return this._sampleCacheDuration.Value;
            }

            set
            {
                this._sampleCacheDuration = value;
            }

        }
    }
}
