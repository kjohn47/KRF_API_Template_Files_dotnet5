﻿namespace $ext_projectname$.App.Injection
{
    using Microsoft.Extensions.DependencyInjection;
    using KRFCommon.Proxy;
    
    public static class AppProxyInjection
    {
        public static void InjectAppProxies( this IServiceCollection services, KRFExternalServices externalServices = null )
        {

        }
    }
}
