﻿namespace $ext_projectname$.Domain.CQRS.Sample.Command
{
    using KRFCommon.CQRS.Command;

    public class SampleCommandOutput: ICommandResponse
    {
        public string Result { get; set; }
    }
}
