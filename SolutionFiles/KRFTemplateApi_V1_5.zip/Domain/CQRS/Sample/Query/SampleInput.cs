﻿namespace $ext_projectname$.Domain.CQRS.Sample.Query
{
    using KRFCommon.CQRS.Query;

    public class SampleInput: IQueryRequest
    {
    }
}
