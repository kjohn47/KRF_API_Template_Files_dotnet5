using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace $ext_projectname$.UnitTest
{
    [TestClass]
    public class BaseUnitTest
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
