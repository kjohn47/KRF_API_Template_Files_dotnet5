﻿namespace $ext_projectname$.App.Injection
{
    using System;
    using Microsoft.AspNetCore.Builder;
    using Microsoft.Extensions.DependencyInjection;
    
    using KRFCommon.Database;
    
    using $ext_projectname$.Infrastructure.Database.Queries;
    using $ext_projectname$.Infrastructure.Database.Context;

    public static class AppDBContextInjection
    {
        public static void InjectAppDBContext( this IServiceCollection services, KRFDatabases databaseSettings = null )
        {
            //Context inject
            services.InjectDBContext<SampleDBContext>( databaseSettings );

            //Inject database query handlers
            services.AddScoped( x => new Lazy<ISampleDatabaseQuery>( () => new SampleDatabaseQuery( x.GetService<SampleDBContext>() ) ) );
        }

        public static void ConfigureAppDBContext( this IApplicationBuilder app, KRFDatabases databaseSettings = null )
        {
            //Inject Migration Automation
            if ( databaseSettings != null && databaseSettings.EnableAutomaticMigration )
            {
                using ( var serviceScope = app.ApplicationServices.GetRequiredService<IServiceScopeFactory>().CreateScope() )
                {
                    serviceScope.ConfigureAutomaticMigrations<SampleDBContext>();
                }
            }
        }
    }
}