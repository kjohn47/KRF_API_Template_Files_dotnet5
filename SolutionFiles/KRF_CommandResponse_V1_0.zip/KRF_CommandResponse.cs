﻿namespace $rootnamespace$
{
    using KRFCommon.CQRS.Command;

    public class $safeitemname$: ICommandResponse
    {
        public string Value { get; set; }
    }
}
