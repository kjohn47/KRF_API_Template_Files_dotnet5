﻿namespace $rootnamespace$
{
    using Microsoft.EntityFrameworkCore;
    using Microsoft.EntityFrameworkCore.Metadata.Builders;   

    public static class $safeitemname$
    {
        public static void Configure(EntityTypeBuilder<TableDataModel> entity)
        {
            entity.ToTable("TableDataModel");
            entity.HasKey(s => s.ID).HasName("PK_TableDataModel");
            entity.Property(s => s.ID).IsRequired().UseIdentityColumn();
        }
    }
}
