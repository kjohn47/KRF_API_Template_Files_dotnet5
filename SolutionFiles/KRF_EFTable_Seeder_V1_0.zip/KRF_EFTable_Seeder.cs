﻿namespace $rootnamespace$
{
    using Microsoft.EntityFrameworkCore.Metadata.Builders;   

    public static class $safeitemname$
    {
        public static void Seed(EntityTypeBuilder<TableDataModel> entity)
        {
            entity.ToTable("TableDataModel");
            entity.HasKey(s => s.ID).HasName("PK_TableDataModel");
            entity.Property(s => s.ID).IsRequired().UseIdentityColumn();

            entity.HasData(new[] {
                new TableDataModel {
                    ID = 1
                }
            });
        }
    }
}